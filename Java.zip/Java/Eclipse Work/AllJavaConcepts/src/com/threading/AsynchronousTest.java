package com.threading;

public class AsynchronousTest {

	public static void handleJob(int jobId) {
		System.out.printf("Thread has <%d> accepted job %d%n", Thread.currentThread().hashCode(), jobId);
		Worker.doWork(5);
		System.out.printf("Thread has <%d> finished job %d%n", Thread.currentThread().hashCode(), jobId);
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

//		handleJob(7);
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				handleJob(5);

			}
		});
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				handleJob(7);

			}
		});
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				handleJob(12);

			}
		});
	
		t1.setDaemon(true);
		t1.start();
	
		handleJob(2);
		t1.join();
		
//		
//		t.start();
//		
//		t2.start();
//		handleJob(2);

	}

}
