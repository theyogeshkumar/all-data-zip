package com.spring.mvc.dao;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.spring.mvc.model.User;

@Repository
public class UserDao {	
	@Autowired 
	private HibernateTemplate hibernatetemplate;
	
	@Transactional
	public int saveuser(User user) {
		int id= (Integer)this.hibernatetemplate.save(user);
		return id;
	}
	
	//getAll
	public List<User> getAll() {
		List<User> ls= hibernatetemplate.loadAll(User.class);
		return ls;
	}
}
