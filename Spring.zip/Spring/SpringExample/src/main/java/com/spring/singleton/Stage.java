package com.spring.singleton;

public class Stage {
	
	private static Stage singleton=null;
	
	private Stage() {
		System.out.println("stage is created");
	}
	
	public static Stage getInstance() {
		if(singleton==null) {
			singleton= new Stage();
		}
		return singleton;
	}

}
