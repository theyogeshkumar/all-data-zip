package com.spring.demo;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.model.Speaker;
import com.spring.repository.SpeakerRepository;
import com.spring.service.SpeakerService;
import com.spring.service.SpeakerServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
    	SpeakerService ss= context.getBean("speakerService",SpeakerService.class);
  
    	
//        System.out.println( "Hello World!" );
//        SpeakerService ss;
        List<Speaker> ls= ss.findAll();
        for (Speaker speaker : ls) {
			System.out.println(speaker.getFirst_name()+"  "+speaker.getLast_name());
		}
        
    }
}
