package com.thisexample;

public class First {
	
	public void fun() {
		System.out.println("inside fun Class First");
	}
	public void foo() {
		System.out.println("inside foo Class First");
	}

}
