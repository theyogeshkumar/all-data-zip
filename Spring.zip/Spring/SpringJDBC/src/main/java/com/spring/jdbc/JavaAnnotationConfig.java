package com.spring.jdbc;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.spring.jdbc.controller.StudentDaoImpl;
import com.spring.jdbc.dao.StudentDao;

@Configuration
@ComponentScan(basePackages = "com/spring/jdbc/controller")
public class JavaAnnotationConfig {

	@Bean("ds")
	public DriverManagerDataSource getDataSource() {
		DriverManagerDataSource ds= new DriverManagerDataSource();
		ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		ds.setUrl("jdbc:sqlserver://localhost;databaseName=SpringJdbcExample;instanceName=SQLEXPRESS2019");
		ds.setUsername("sa");
		ds.setPassword("Password_123");
		return ds;
		
	}
	
	@Bean("jdbcTemplate")
	public JdbcTemplate getJdbcTemplate() {
		JdbcTemplate jdbcTemplate= new JdbcTemplate();
		jdbcTemplate.setDataSource(getDataSource());
		return jdbcTemplate;
	}
	

	@Bean("studentDaoImpl")
	public StudentDaoImpl getStudentDao() {
		StudentDaoImpl studentDaoImpl= new StudentDaoImpl();
		studentDaoImpl.setJdbcTemplate(getJdbcTemplate());
		return studentDaoImpl;
	}
	
}
