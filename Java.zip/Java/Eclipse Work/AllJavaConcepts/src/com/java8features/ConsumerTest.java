package com.java8features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class Employee{
	
	int hours;
	double rate;
	public Employee(int hours, double rate) {
		super();
		this.hours = hours;
		this.rate = rate;
	}
	
	public double netIncome() {
		return rate*hours;
	}

	@Override
	public String toString() {
		return "Employee [hours=" + hours + ", rate=" + rate + "]";
	}
	
	
}

public class ConsumerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> ls= new ArrayList<>();
		ls.add(new Employee(18, 150));
		ls.add(new Employee(9, 150));
		ls.add(new Employee(10, 150));
		ls.add(new Employee(12, 150));
		
//		for(Employee e:ls) {
//			if(e.hours>12)
//				System.out.println(e);
//		}
		
//		Predicate<Employee> p= e -> e.hours>12;
//		System.out.println(p.test());
		
		List<Integer> l= Arrays.asList(1,2,3,4,5,6,7,8,9,10); 
		
		System.out.println(l.stream().filter(n->(n%2==0)).collect(Collectors.toList())); 
		System.out.println(l.stream().filter(n->n%2==0).map(n->n*n).collect(Collectors.toList()));
		System.out.println(l.stream().filter(n->(n%2==1)).collect(Collectors.toList())); 
		
		System.out.println(l.stream().filter(n->n%2==1).map(n->n*n).collect(Collectors.toList()));

	}

}
