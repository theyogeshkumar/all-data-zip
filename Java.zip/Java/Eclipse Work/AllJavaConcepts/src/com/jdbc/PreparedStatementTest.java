package com.jdbc;

//import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PreparedStatementTest {

	public static void main(String[] args) throws SQLException {
		
//		DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
		try(Connection con= DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=AdventureWorks2019;user=sa;password=Password_123")){
			try(PreparedStatement pstmt=con.prepareStatement("update Person.Address set ?,? Where AddressID=1")){
//				ResultSet rs= pstmt.executeQuery();
				pstmt.setString(1, "Rohini");
				pstmt.setString(2, "Delhi");
				
				Statement stmt= con.createStatement();
				ResultSet rs= stmt.executeQuery("Select Top 10 AddressID,AddressLine1,AddressLine2 from Person.Address Order BY AddressID");
//				pstmt.setString(1, "AddressID");
//				pstmt.setString(2, "AddressLine1");
//				pstmt.setString(3, "AddressLine2");
				
				
				
				while(rs.next()) {
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
				}
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
