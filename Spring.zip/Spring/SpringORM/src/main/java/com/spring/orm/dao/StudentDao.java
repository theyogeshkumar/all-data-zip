package com.spring.orm.dao;

import java.util.List;

import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import com.spring.orm.entities.Student;

public class StudentDao {

	HibernateTemplate hibernateTemplate;
	
	@Transactional
	public int insert(Student student) {
		Integer row= (Integer) this.hibernateTemplate.save(student);
		return row;
	}
	
	
	public Student get(int id) {
		Student student= this.hibernateTemplate.get(Student.class,id);
		return student;
	}
	
	
	public List<Student> getAll() {
		List<Student> students= this.hibernateTemplate.loadAll(Student.class);
		return students;
	}
	
	@Transactional
	public void delete(int id) {
		Student student= this.hibernateTemplate.get(Student.class,id);
		this.hibernateTemplate.delete(student);
	}
	
	@Transactional
	public void update(Student student) {
		this.hibernateTemplate.update(student);
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
}
