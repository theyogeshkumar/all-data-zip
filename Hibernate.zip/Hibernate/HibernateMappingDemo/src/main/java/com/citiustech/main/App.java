package com.citiustech.main;


import java.util.Arrays;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

import com.citiustech.one_to_one.Employee;
import com.citiustech.one_to_one.Machine;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        SessionFactory sf= new Configuration().configure().buildSessionFactory();
        Session session= sf.openSession();
        Transaction tran=session.beginTransaction();
        
//        System.out.println("main");
          //insert
//        Employee emp= new Employee();
//        Machine m= new Machine();
//        
//        emp.setCt_name("SatishA1");
//        emp.setName("satish Anuse");
//        
//        
//        m.setMachine_name("lenevo");
//        m.setType("laptop");
//        
//        
//        m.setEmployee(emp);
//        emp.setMachine(m);
//        
//        //insert
//        session.save(emp);
//        session.save(m);
        
        //fetch single
//        Employee emp= (Employee)session.get(Employee.class, 3);
//        System.out.println(emp.getName()); 
//        System.out.println(emp.getCt_name());
//        System.out.println(emp.getMachine().getType());
//        System.out.println(emp.getMachine().getMachine_name());
//        System.out.println(emp.getMachine().getMachine_id());
        
//        //get all
        Query q=session.createQuery("from Employee"); 
        List<Employee> ls=q.getResultList();
        for (Employee employee : ls) {
			
        	System.out.print(employee.getId()+" ");
        	System.out.print(employee.getName()+" ");
			System.out.print(employee.getCt_name()+" ");
			System.out.print(employee.getMachine().getType()+" ");
			System.out.print(employee.getMachine().getMachine_id()+" ");
			System.out.println(employee.getMachine().getMachine_name()+" ");	
		}
        
//       //inner join Query
//        Query q=session.createQuery("select e.id,e.name,e.ct_name,m.machine_id,m.type,m.machine_name from Employee as e Inner Join e.machine as m");
//        List<Object[]> ls=q.getResultList();
//        for (Object[] object : ls) {
//			System.out.println(Arrays.toString(object)); 
//		}
        
        //sql statement using native Query
        
//        NativeQuery<String> nq=session.createNativeQuery("select name from Employee where id=3");
//        List<String> ls=nq.getResultList();
//        if(ls.size()<1)
//        	System.out.println("no data available");
//        else
//        	System.out.println(ls);
        
//        for (String employee : ls) {
//			System.out.println(employee);
//		}
        //
//        CriteriaBuilder cb=session.getCriteriaBuilder();
//        CriteriaQuery<Employee> cq=cb.createQuery(Employee.class);
//        
//        Root<Employee> r=cq.from(Employee.class);
//        cq.select(r);
//        
//        Machine m=new Machine();
//        m.setMachine_name("dell");
//        cq.where(cb.equal(r.get("machine"),m));
//        
//        List<Employee> ls=session.createQuery(cq).getResultList();
//        System.out.println(ls.toString());
        
        
        
//        Criteria c=session.createCriteria(Employee.class);
////        crit.setMaxResults(2);
//        List<Employee> ls=c.list();
//        for (Employee employee : ls) {
//        	System.out.println(ls.toString());
//		}
        
        
        
        tran.commit();
        session.close();
        sf.close();
    }
}
