package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.spring.model.Speaker;
import com.spring.repository.SpeakerRepository;
import com.spring.repository.SpeakerRepositoryImpl;

@Service("speakerService")
//@Scope(value=BeanDefinition.SCOPE_PROTOTYPE)  //defining scope in the fully annotation based configuration 
public class SpeakerServiceImpl implements SpeakerService {
	
	private SpeakerRepository speakerRepository;
	
	public List<Speaker> findAll() {
		//bussiness logic
		
		return speakerRepository.findAll();
	}
	
	//getter and setter
	public SpeakerRepository getSpeakerRepository() {
		return speakerRepository;
	}
	@Autowired
	public void setSpeakerRepository(SpeakerRepository speakerRepository) {
		System.out.println("speakerServiceImpl Setter");
		this.speakerRepository = speakerRepository;
	}
	
	public SpeakerServiceImpl() {
		System.out.println("speakerServiceImpl no args constructor");
		// TODO Auto-generated constructor stub
	}
	
	public SpeakerServiceImpl(SpeakerRepository speakerRepository) {
		System.out.println("speakerServiceImpl speakerRepository args constructor");
		this.speakerRepository = speakerRepository;
	}
	
	
}
