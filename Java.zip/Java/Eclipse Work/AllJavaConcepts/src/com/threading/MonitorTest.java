package com.threading;

class Outer{
	 class Inner{
		int balance;
		
	}
}

public class MonitorTest {
	
	static class JointAccount{
		private  int balance;
		
		public void deposit(int money) {
			synchronized (this) {
				balance+=money;
			}
			
		}
		
		public synchronized boolean  withdraw(int money) {
				boolean success=false;
			if(balance>=money) {
				Worker.doWork(5);
				balance-=money;
				return true;
			}
			return success;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		JointAccount a= new JointAccount();
		a.deposit(5000);
		
		Thread t= new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("withdrawal 1");
				if(a.withdraw(2000)) {
					System.out.println("Withdraw 1 "+a.balance);
				}else {
					System.out.println("Withdrawal failed.");
				}
				
			}
		} );
		t.start();
		
	
		
		System.out.println("withdrawal 2");
		if(a.withdraw(4000)) {
			System.out.println("Withdraw 2 "+a.balance);
		}else {
			System.out.println("Withdrawal failed.");
		}
		
		
		
//		MonitorTest acc= new MonitorTest();
//		acc.deposit(5000);
		
		System.out.println("balance "+a.balance); 
		
//		System.out.println(acc.balance);
		
		

	}

}
