package com.refex2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/refex2/refconfig.xml");
		Question obj=(Question)context.getBean("question");
		
		System.out.println(obj);
		
		System.out.println();
		
		Answer obj1=(Answer)context.getBean("answer");
		System.out.println(obj1);
	}
}
