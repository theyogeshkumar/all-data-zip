package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.mvc.model.User;
import com.spring.mvc.service.UserService;
@Controller
public class FormController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("form")
	public String form() {
		return "form";
	}
	
	@RequestMapping(path = "processform",method = RequestMethod.POST)
	public String processform(@ModelAttribute User user,Model model) {
		System.out.println(user);
//		model.addAttribute("user",user);
		this.userService.createuser(user);
//		return "redirect:userlist";
		return "processform";
	}
	
	@RequestMapping(path = "userlist")
	public ModelAndView getAllUsers(@ModelAttribute User user) {
//		System.out.println(user);
		ModelAndView modelAndView= new ModelAndView();
//		model.addAttribute("user",user);
		List<User> ls=new ArrayList<>();
		ls= this.userService.getAll();
		modelAndView.addObject("ls", ls);
		modelAndView.setViewName("userlist");
		return modelAndView;
	}
}
