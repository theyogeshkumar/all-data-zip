package com.stereotyeEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/stereotyeEx/standaloneconfig.xml");
		Employee emp=context.getBean("employe",Employee.class);
		System.out.println(emp.getEmp_id());
		System.out.println(emp.getEmp_name());
		System.out.println(emp.getEmp_projects());
		System.out.println(emp);

	}

}
