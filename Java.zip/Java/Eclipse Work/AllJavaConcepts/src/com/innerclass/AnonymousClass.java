package com.innerclass;

class Greeting{
	protected void hello(){
		System.out.println("Hello");
	}
}

 class India {
	//Anonymous class
	String name="india";
	 void hello() {
		System.out.println("hello my greet");
	}
	Greeting g=new Greeting(){
		protected void hello() {
			System.out.println("anonymousFunction "+name);
		}
	};
	
}

public class AnonymousClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Greeting g= new Greeting();
		g.hello();	
		
		India i=new India();
		i.hello(); 
		i.g.hello();
		
		//that is a anonymous class and it is a inner class and sub class of greeting.
//		Greeting g1=new Greeting(){
//			protected void hello() {
//				System.out.println("anonymousFunction ");
//			}
//		};
//		g1.hello();
		
		
	}

}
