package com.lifecycle;

public class Test {

	private int my_number;

	public int getMy_number() {
		return my_number;
	}

	public void setMy_number(int my_number) {
		this.my_number = my_number;
	}

	public Test(int my_number) {
		super();
		this.my_number = my_number;
	}

	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Test [my_number=" + my_number + "]";
	}
	
	//lifecycle
	public void start() {
		System.out.println("init method has been called");
	}

	public void stop() {
		System.out.println("destroy method has been called");
	}
}
