package com.authenticate;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Auth {
//	@Before("execution(* com.shopping.ShoppingImpl.buyProduct())")
//	public void displayDiscountOffer() {
//		System.out.println("You have discount of 15% as you are prime user");
//		System.out.println("Enjoy your shopping");
//	}
	@After("execution(* com.shopping.ShoppingImpl.buyProduct())")
	public void msg() {
		System.out.println("hey");
		System.out.println("pops");
	}
	

}