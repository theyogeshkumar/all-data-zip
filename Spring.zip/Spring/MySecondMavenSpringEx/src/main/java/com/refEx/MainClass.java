package com.refEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/refEx/refconfig.xml");
		A obj = (A) context.getBean("aref");

		System.out.println(obj);
		System.out.println(obj.getNumber());
		System.out.println(obj.getObject());
		System.out.println();
		System.out.println("---------------");
		A obj1 = (A) context.getBean("aref1");
		System.out.println(obj1);
		System.out.println(obj1.getNumber());
		System.out.println(obj1.getObject());
		
		System.out.println();
		System.out.println("---------------");
		A obj2 = (A) context.getBean("aref2");
		System.out.println(obj2);
		System.out.println(obj2.getNumber());
		System.out.println(obj2.getObject());
	}
}
