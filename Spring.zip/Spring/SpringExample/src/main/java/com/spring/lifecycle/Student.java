package com.spring.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Student{ //implements InitializingBean,DisposableBean{
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
		System.out.println("in setter");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		System.out.println("in constructor");
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	
	//this is for spring lifecycle 
	@PostConstruct
	public void init() {
		System.out.println("in init function");
	}
	@PreDestroy
	public void destroy() {
		System.out.println("in destroy function");
	}
	
	//spring lifecycle by using interface Initailize bean and disposable bean
//	public void afterPropertiesSet() throws Exception {
//		// TODO Auto-generated method stub
//		System.out.println("in init function");
//	}
//	public void destroy() throws Exception {
//		// TODO Auto-generated method stub
//		System.out.println("in destroy function");
//	}
}
