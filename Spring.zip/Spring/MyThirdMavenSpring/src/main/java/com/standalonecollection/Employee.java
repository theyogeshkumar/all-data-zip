package com.standalonecollection;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Employee {
	
	private String emp_name;
	private List<String> project_name;
	private Map<Integer,String> department_details;
	private Properties dbconnection;
	
	
	public Properties getDbconnection() {
		return dbconnection;
	}
	public void setDbconnection(Properties dbconnection) {
		this.dbconnection = dbconnection;
	}
	public Map<Integer, String> getDepartment_details() {
		return department_details;
	}
	public void setDepartment_details(Map<Integer, String> department_details) {
		this.department_details = department_details;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public List<String> getProject_name() {
		return project_name;
	}
	public void setProject_name(List<String> project_name) {
		this.project_name = project_name;
	}
	@Override
	public String toString() {
		return "Employee [emp_name=" + emp_name + ", project_name=" + project_name + ", department_details="
				+ department_details + "]";
	}
	
	
	
	
}
