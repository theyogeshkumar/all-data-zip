package com.autowiringUsingAnnotation;

public class Address {
	private String house_no;
	private String locality;
	private String state;
	public String getHouse_no() {
		return house_no;
	}
	public void setHouse_no(String house_no) {
		this.house_no = house_no;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Address(String house_no, String locality, String state) {
		super();
		this.house_no = house_no;
		this.locality = locality;
		this.state = state;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Address [house_no=" + house_no + ", locality=" + locality + ", state=" + state + "]";
	}
	
	
	
}
