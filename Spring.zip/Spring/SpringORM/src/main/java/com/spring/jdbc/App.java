package com.spring.jdbc;

import java.util.List;
import java.util.Scanner;

import javax.xml.crypto.Data;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.dao.StudentDao;
import com.spring.orm.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
//        System.out.println( "Hello World!" );
		ApplicationContext context = new ClassPathXmlApplicationContext("springconfig.xml");
		StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
		Scanner sc = new Scanner(System.in);
//		Student s = new Student();
//		s.setStudentId(2);
//		s.setName("saurabh Sisodia");
//		s.setCity("New Delhi");
//		 insert
//    	studentDao.insert(s);

//		 get
//    	Student s=studentDao.get(3);
//    	System.out.println("getting the data...." );
//    	System.out.println(s);

//		 get all
//    	List<Student> ls=studentDao.getAll();
//    	for (Student student : ls) {
//			System.out.println(student);
//		}

//		 delete
//    	studentDao.delete(0);
//    	System.out.println("deleted"); 

//		 update
//		try {
//			studentDao.update(s);
//			System.out.println("updated");
//		} catch (Exception e) {
//			System.out.println("row is not present in the database");
//		}

		boolean go = true;
		while (go) {
			System.out.println("Enter 1. to insert");
			System.out.println("Enter 2. to get by id");
			System.out.println("Enter 3. to get All");
			System.out.println("Enter 4. to delete");
			System.out.println("Enter 5. to update");
			System.out.println("Enter 6. to exit the Application.");
			int input = sc.nextInt();
			switch (input) {
			case 1:
				Student s = new Student();
				System.out.println("Enter new Id");
				s.setStudentId(sc.nextInt());
				sc.nextLine();
				System.out.println("Enter name of student");
				s.setName(sc.nextLine());
				System.out.println("Enter city of student");
				s.setCity(sc.nextLine());
				// insert
				try {
		    	studentDao.insert(s);
		    	}catch(Exception e) {
		    		System.out.println("duplicate id: Key already Exists With this id");
		    	}
				break;
			case 2:
				// get
				System.out.println("Enter Id to get data");
		    	s=studentDao.get(sc.nextInt());
		    	System.out.println("getting the data...." );
		    	System.out.println(s);
				break;
			case 3:
				// get all
		    	List<Student> ls=studentDao.getAll();
		    	for (Student s1 : ls) {
					System.out.println(s1);
				}
				break;
			case 4:
				// delete
				System.out.println("Enter Id to delete data");
		    	studentDao.delete(sc.nextInt());
		    	System.out.println("deleted"); 
				break;
			case 5:
				// update
				Student s1 = new Student();
				System.out.println("Enter Id to update");
				s1.setStudentId(sc.nextInt());
				sc.nextLine();
				System.out.println("Enter name of student to update");
				s1.setName(sc.nextLine());
				System.out.println("Enter city of student to update");
				s1.setCity(sc.nextLine());
				try {
					studentDao.update(s1);
					System.out.println("updated");
				} catch (Exception e) {
					System.out.println("row is not present in the database");
				}
				break;
			case 6:
				go=false;
				break;

			default:
				System.out.println("Enter Correct Input");
				System.out.println("____________________________");
				break;
			}
		}
		System.out.println("Thank you for using this Application");

	}
}
