package com.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.spring.mvc.dao.UserDao;
import com.spring.mvc.model.User;
@Service
public class UserService {
	@Autowired
	private UserDao userDao; 
	
	public int createuser(User user) {
		int id=(Integer)this.userDao.saveuser(user);
		return id;
	}
	
	public List<User> getAll() {
		List<User> ls= this.userDao.getAll();
		return ls;
	}
}
