package com.spring.jdbc;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.controller.StudentDaoImpl;
import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.pojo.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//        System.out.println( "Hello World!" );
//    	ApplicationContext context= new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
    	ApplicationContext context= new AnnotationConfigApplicationContext(JavaAnnotationConfig.class);
//    	JdbcTemplate template= context.getBean("jdbcTemplate",JdbcTemplate.class);
//    	System.out.println(template);
    	
//    	String query="insert into student(id, name, city) values(?,?,?)";
//    	int result=template.update(query,2,"Saurabh","delhi");
//    	System.out.println("number of rows inserted "+result);
    	StudentDao s= context.getBean("studentDaoImpl",StudentDao.class);
    	
    	Scanner sc= new Scanner(System.in);
//    	Student student= new Student();
//    	System.out.println("Enter id");
//    	student.setId(sc.nextInt());
//    	System.out.println("Enter Name");
//    	sc.nextLine();
//    	student.setName(sc.nextLine());
//    	System.out.println("Enter City");
//    	student.setCity(sc.nextLine());
    	
    	//insert
//    	int res=s.insert(student);
//    	System.out.println(res+" row Inserted");
    	
    	//update
//    	int res=s.update(student);
//    	System.out.println(res+" row updated");
    	
    	//delete
//    	System.out.println("Enter Id to delete");
//    	int res=s.delete(sc.nextInt());
//    	System.out.println(res+" row deleted");
    	
    	//fetch By ID
//    	System.out.println("Enter Id to fetch");
//    	try{Student student=s.fetchById(sc.nextInt());
//    	System.out.println(student);
//    	}catch(EmptyResultDataAccessException e) {
//    		System.out.println("No Item Available with that Id.");
//    	}
    	
    	//fetchAll
    	List<Student> ls= s.fetchAll();
    	for (Student studen : ls) {
    		System.out.println(studen);
		}
    }
}
