package com.employee.model;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

public class EmployeeDao {

	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Transactional
	// method for inserting employee
	public int insertEmployee(Employee employee) {
		int row = (Integer) this.hibernateTemplate.save(employee);
		return row;
	}

	@Transactional
	public void deleteEmployee(int emp_id) {
		Employee employee = this.hibernateTemplate.get(Employee.class, emp_id);
		try {
			this.hibernateTemplate.delete(employee);
			System.out.println("Employee Deleted");
		} catch (IllegalArgumentException ex) {
			System.out.println("Already Empty");
		}

	}
	
	@Transactional
	public void updateEmployee(Employee employee) {
		this.hibernateTemplate.update(employee);
		System.out.println("Updated");
	}
	
	public Employee getOneEmployee(int emp_id) {
		Employee emp=this.hibernateTemplate.get(Employee.class, emp_id);
		
		return emp;
	}
	
	public List<Employee> getAllEmployee(){
		List<Employee> list=this.hibernateTemplate.loadAll(Employee.class);
		return list;
	}
}
