package com.citiustech.one_to_many;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Answer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String answername;
	private String postedby;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAnswername() {
		return answername;
	}
	public void setAnswername(String answername) {
		this.answername = answername;
	}
	public String getPostedby() {
		return postedby;
	}
	public void setPostedby(String postedby) {
		this.postedby = postedby;
	}
	public Answer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Answer(int id, String answername, String postedby) {
		super();
		this.id = id;
		this.answername = answername;
		this.postedby = postedby;
	}
	@Override
	public String toString() {
		return "Answer [id=" + id + ", answername=" + answername + ", postedby=" + postedby + "]";
	}
	
	
}
