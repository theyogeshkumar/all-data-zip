package com.innerclass;


 class Outer{
	//variable
	static int out=34;
	private int var=67;
	//function
	void print() {
		System.out.println("Outer Function");
	}
	//another nested class
	    class Inner{
		
		int inner=345;
		void fun() {
			System.out.println("Inner Function");
			out=55;
			var=33;
			System.out.println(var);
		}
		
		
	}
}

 class Example {
	 int s=34;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Outer outer=new Outer();
//		outer.out=344;
//		System.out.println(outer.out); 
//		outer.print();
		
		//if inner class is static no need to create instatce of outer Class 
		//Outer.Inner inn=new Outer.Inner();
		//inn.fun();
		
		//non-static class
		//if we have create outer class object or instance then
		//we need outer class object to initialize the inner class  
		Outer.Inner n=outer.new Inner();
		n.fun();
		
		
//		Outer.Inner i= new Outer.Inner();
//		i.fun();
		

	}

}
