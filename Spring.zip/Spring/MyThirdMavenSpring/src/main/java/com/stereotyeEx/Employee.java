package com.stereotyeEx;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("employe")
public class Employee {
	@Value("1")
	private int emp_id;
	@Value("Yogesh Kumar")
	private String emp_name;
	@Value("#{project_names}")
	private List<String> emp_projects;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public List<String> getEmp_projects() {
		return emp_projects;
	}
	public void setEmp_projects(List<String> emp_projects) {
		this.emp_projects = emp_projects;
	}
	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_projects=" + emp_projects + "]";
	}
	
	
}
