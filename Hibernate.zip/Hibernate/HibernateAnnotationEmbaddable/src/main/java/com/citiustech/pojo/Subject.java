package com.citiustech.pojo;

import javax.persistence.Embeddable;

@Embeddable
public class Subject {
	private String first;
	private String sec;
	private String third;
	private String fourth;
	private String fifth;
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getSecond() {
		return sec;
	}
	public void setSecond(String second) {
		this.sec = second;
	}
	public String getThird() {
		return third;
	}
	public void setThird(String third) {
		this.third = third;
	}
	public String getFourth() {
		return fourth;
	}
	public void setFourth(String fourth) {
		this.fourth = fourth;
	}
	public String getFifth() {
		return fifth;
	}
	public void setFifth(String fifth) {
		this.fifth = fifth;
	}
	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Subject(String first, String second, String third, String fourth, String fifth) {
		super();
		this.first = first;
		this.sec = second;
		this.third = third;
		this.fourth = fourth;
		this.fifth = fifth;
	}
	@Override
	public String toString() {
		return "Subject [first=" + first + ", second=" + sec + ", third=" + third + ", fourth=" + fourth + ", fifth="
				+ fifth + "]";
	}
	
	
	
	

}
