package com.citiustech.pojo;

public class Address {
	
	private String houseNo;
	private String locality;
	private String state;
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String houseNo, String locality, String state) {
		super();
		this.houseNo = houseNo;
		this.locality = locality;
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", locality=" + locality + ", state=" + state + "]";
	}
	
	

}
