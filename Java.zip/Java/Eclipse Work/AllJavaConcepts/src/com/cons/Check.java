package com.cons;

public class Check {

	static Check c;
	long id;
	String name;
	String address;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
//	private Check() {
//		
//	}
	
	private Check(long id,String name,String address) {
		this.address=address;
		this.name=name;
		this.id=id;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Check [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	
	public static  Check getInstance() {
		if(c==null) {
			c=new Check(1,"Sonu","Delhi");
		}
		return c;
	}
	public static  Check setInstance(long id,String name,String address) {
		if(c==null) {
			c=new Check(1,"Sonu","Delhi");
			c.setId(id);
			c.setName(name);
			c.setAddress(address);
		}
		return c;
	}
	
	
}
