package com.citiustech.one_to_many;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OneToManyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf= new Configuration().configure().buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx= session.beginTransaction();
		
			//insert
//		 	Answer ans1=new Answer();    
//		    ans1.setAnswername("Spring is a framework of Java");    
//		    ans1.setPostedby("Yogesh Sisodia");    
//		        
//		    Answer ans2=new Answer();    
//		    ans2.setAnswername("It is used to create standalone application and easier than previous orm framework.");    
//		    ans2.setPostedby("Yogesh Sisodia");    
//		            
//		    ArrayList<Answer> list1=new ArrayList<Answer>();    
//		    list1.add(ans1);    
//		    list1.add(ans2);    
//		          
//		    Question question1=new Question();    
//		    question1.setQname("What is Spring?");    
//		    question1.setAnswers(list1);    
//		        
//		    session.persist(question1);   
		
			//get all ans by ques ID
			Question ques=session.get(Question.class, 5);
			System.out.println(ques.getQname());
			
			List<Answer> ans= ques.getAnswers();
			for (Answer answer : ans) {
				System.out.println(answer);
			}
		
		tx.commit();
		session.close();
		sf.close();

	}

}
