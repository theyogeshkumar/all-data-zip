package com.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Test3 {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Test3(String name) {
		super();
		this.name = name;
	}

	public Test3() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Test3 [name=" + name + "]";
	}
	@PostConstruct
	public void start() {
		System.out.println("this is my init method");
	}
	@PreDestroy
	public void stop() {
		System.out.println("this is my destroy method");
	}
}
