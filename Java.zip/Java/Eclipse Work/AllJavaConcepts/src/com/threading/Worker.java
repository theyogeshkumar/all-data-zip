package com.threading;

public class Worker {
	public static void doWork(int count) {
		long future=System.currentTimeMillis()+1000*count;
		while(System.currentTimeMillis()<future);
	}

}
