package com.cons;

import java.awt.Checkbox;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Check c= Check.getInstance();
//		Check c2=Check.setInstance(1, "Yogesh", "India");
		
		Check c1=Check.getInstance();
//		c2.setAddress("Hello");
//		System.out.println(c);
		System.out.println(c1);
//		System.out.println(c2);
		Check c3=Check.setInstance(100, "Yogesh Sisodia", "Bharat");

		c3.setId(100);
		c3.setName("Yogesh Sisodia");
		c3.setAddress("Bharat");
		
		System.out.println("c3 "+c3);
//		System.out.println("c2 "+c2);
		System.out.println("c1 "+c1);
		System.out.println("c "+c);
		
	}

}
