package com.staticexample;

import com.demo.Main;

public class FirstStaticClass extends Main {
	   
	 
	   static {
		   aa=12;
	   }
	   public  static int aa=5;
	   int a=37;

	public static void printMyName(String name) {
		System.out.printf("hello %s",name);
		System.out.println();
		System.out.println(aa);
	}
	public void hello(String name) {
		System.out.printf("hello %s",name);
		System.out.println();
		System.out.println(aa);
	}
	
	public static void main(String[] args) {
//		System.out.println(aa);
//		printMyName("sisodia");
		FirstStaticClass obj=new FirstStaticClass();
		obj.hello("sonu");
		
	}
	
	
	
}
