package com.citiustech.withoutannotation;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class WithoutAnnotationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = sf.openSession();
		Transaction t= session.beginTransaction();
		
		//save in to the database
		Employee emp= new Employee("Gaurav","Sisodia",1550000);
		session.save(emp);
		
		//delete data
//		int id=5;
//		Query qr= session.createQuery("delete from employee_data where id=:a");
//		qr.setParameter("a",id );
		
//		fetch all from the database
		Query qr= session.createQuery("from Employee");
		List<Employee> list=qr.getResultList();
		for (Employee employee : list) {
			System.out.println(employee);
		}
		
		
//		doing all operation in without annotaion is not complete
		
		t.commit();
		
		System.out.println("done ");
		session.close();
		sf.close();

	}

}
