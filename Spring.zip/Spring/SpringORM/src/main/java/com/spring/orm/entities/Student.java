package com.spring.orm.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="my_student_table")
public class Student {
	@Id
	private int id;
	private String name;
	private String city;
	public int getStudentId() {
		return id;
	}
	public void setStudentId(int studentId) {
		this.id = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studentId, String name, String city) {
		super();
		this.id = studentId;
		this.name = name;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + id + ", name=" + name + ", city=" + city + "]";
	}
	
	
}
