package com.spring.repository;

import java.util.List;

import com.spring.model.Speaker;

public interface SpeakerRepository {
	public List<Speaker> findAll();
}
