package com.bean;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.employee.model.Employee;
import com.employee.model.EmployeeDao;

public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context=new ClassPathXmlApplicationContext("com/employee/model/config.xml");
       EmployeeDao empDao= context.getBean("empDao",EmployeeDao.class);
       
       //InsertEmployee
//       Employee emp=new Employee();
//       emp.setEmp_id(5);
//       emp.setEmp_name("Sneha Athwale");
//       int row=empDao.insertEmployee(emp);
//       System.out.println(row);
       
       
       //deleteEmployee
//      empDao.deleteEmployee(2);
       
       //UpdateEmployee
//       Employee emp=new Employee();
//       emp.setEmp_id(11);
//       emp.setEmp_name("Sneha Athwale");
//       empDao.updateEmployee(emp);
      
      //getOneEmployee
//       Employee emp=empDao.getOneEmployee(5);
//       System.out.println(emp.getEmp_id()+"  -  "+emp.getEmp_name());
       
       
       //getAllEmployee
     List<Employee> list=  empDao.getAllEmployee();
     for (Employee emp:list) {
    	System.out.println(emp.getEmp_id()+"  -  "+emp.getEmp_name());
	}
     
       
    }
}
