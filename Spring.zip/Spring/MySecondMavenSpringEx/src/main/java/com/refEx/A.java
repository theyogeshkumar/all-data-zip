package com.refEx;

public class A {
	private int number;
	private B object;
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public B getObject() {
		return object;
	}
	public void setObject(B object) {
		this.object = object;
	}
	@Override
	public String toString() {
		return "A [number=" + number + ", object=" + object + "]";
	}
	
	
}
