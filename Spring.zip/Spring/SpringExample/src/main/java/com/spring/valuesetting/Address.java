package com.spring.valuesetting;

public class Address {
	private int pincode;
	private String city;
	private String State;
	
public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
		System.out.println("setting pincode");
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
		System.out.println("setting city");
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
		System.out.println("setting state");
	}

		public Address() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("in default constructor");
	}

		public Address(int pincode, String city, String state) {
		super();
		this.pincode = pincode;
		this.city = city;
		State = state;
		System.out.println("in the parametirized constructor");
	}
	@Override
	public String toString() {
		return "Address [pincode=" + pincode + ", city=" + city + ", State=" + State + "]";
	}
	
	

}
