package com.spring.annotation.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		ApplicationContext con=new ClassPathXmlApplicationContext("com/spring/annotation/autowiring/config.xml");
		ApplicationContext con= new AnnotationConfigApplicationContext(AnnotationConfig.class);
		Person p=con.getBean("person",Person.class);
		System.out.println(p);
		p.study();
		
	}

}
