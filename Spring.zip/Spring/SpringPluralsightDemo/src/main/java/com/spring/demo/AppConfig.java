package com.spring.demo;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.spring.repository.SpeakerRepository;
import com.spring.repository.SpeakerRepositoryImpl;
import com.spring.service.SpeakerService;
import com.spring.service.SpeakerServiceImpl;

@Configuration
@ComponentScan(value={"com.spring"})
public class AppConfig {
	
	/*@Bean(name="speakerRepository")		
//	@Scope(value=BeanDefinition.SCOPE_SINGLETON) //setting the scope
	public SpeakerRepository getSpeakerreRepository() {
		return new SpeakerRepositoryImpl();
	}
	
	@Bean(name="speakerService")
//	@Scope(value=BeanDefinition.SCOPE_SINGLETON)
	public SpeakerService getSpeakerService() {
//		SpeakerServiceImpl speakerService= new SpeakerServiceImpl(getSpeakerreRepository());
		SpeakerServiceImpl speakerService= new SpeakerServiceImpl();
		//		speakerService.setSpeakerRepository(getSpeakerreRepository());
		return speakerService;
	}
	 */

}
