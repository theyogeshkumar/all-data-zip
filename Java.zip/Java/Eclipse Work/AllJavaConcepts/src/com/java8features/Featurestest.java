package com.java8features;

interface Filter{
	public boolean allowed( int value);//single abstract method is called as functional interface
//	public boolean allow(int value);
}


class Algorithm{
	
	public static void printAll(int []arr) {
		for (int i : arr) {
			System.out.println(i); 
		}
	}
	
	public static void printIf(int []arr,Filter check) {
		for (int i : arr) {
			if(check.allowed(i))
				System.out.println(i); 
		}
	}

}

class First{
	public static boolean isgreater(int value) {
		return value>51;
	}
}

class Yogesh implements Filter{
	public boolean allowed(int value) {
		return value%2==1; 
	}
}

class Manish implements Filter{
	public boolean allowed(int value) {
		return value%2==0; 
	}
}

public class Featurestest {

	public static boolean isGreater(int value) {
		return value>5;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,35,445,46,5,655,43,17,11,111,121};
//		printAll(arr);
//		System.out.println("PrintOdd");
//		Algorithm.printIf(arr, new Yogesh());
//		Algorithm.printIf(arr, new Manish());
		
		//anonymous class
//		Algorithm.printIf(arr, new Filter() {
//
//			@Override
//			public boolean allowed(int value) {
//				// TODO Auto-generated method stub
//				for(int i=2;i<value;i++) {
//					if(value%i==0 )
//						return false;
//				}
//				return true;
//			}
//			
//		});
//		Algorithm.printIf(arr, First::isgreater);//Method reference
		//wherever there is a function interface is accepted you can pass method reference
		
		Algorithm.printIf(arr,(x) -> x<19);//this is lambda expression
		
		
		
	}

}
