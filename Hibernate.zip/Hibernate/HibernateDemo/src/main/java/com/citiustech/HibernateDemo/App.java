package com.citiustech.HibernateDemo;

import java.util.List;

import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.citiustech.pojo.Employee;
import com.citiustech.pojo.Location;

public class App 
{
    public static void main( String[] args )
    {
        
        SessionFactory sf=new  Configuration().configure().buildSessionFactory();
        Session session= sf.openSession();
        Transaction t= session.beginTransaction();
        
//        insert       
//        Employee emp= new Employee();
//        emp.setFirst_name("gaurav");
//        emp.setLast_name("singh");
//        emp.setSalary(65000);
//
//        Location l= new Location();
//        l.setPincode(60735);
//        l.setCity("mayapur");
//        l.setState("uttarpardesh");
//        l.setCountry("India");
//        
//        emp.setLocation(l);
//        session.save(emp);
        
        //delete
//        Query qr=session.createQuery(" delete Employee where id=:i");
//        qr.setParameter("i",7);
//        qr.executeUpdate();
//        System.out.println("done"); 
        
        //update
//        Query qr= session.createQuery("update Employee set first_name=:a,last_name=:b,salary=:c where id=:d");
//        qr.setParameter("a", "Yogesh");
//        qr.setParameter("b", "Sisodia");
//        qr.setParameter("c", (double)100000);
//        qr.setParameter("d", 1);
//        qr.executeUpdate();
//        System.out.println("updated");
        
        //get single 
//        Query qr = session.createQuery(" from Employee where id=:i");
//		qr.setParameter("i", 2);
//		Employee em=(Employee) qr.getSingleResult();
//		System.out.println(em);
		
		//get single alternate method
//		Employee st= session.load(Employee.class, 1);
//		System.out.println(st);
//        //get method
//		Employee st= session.get(Employee.class, 1);
//		System.out.println(st);
        
        //fetch all
        Query qr1=session.createQuery("from Employee");
        List<Employee> ls= qr1.getResultList();
        for(Employee e:ls) {
        	System.out.println(e); 
        }
        
        
        t.commit();
        System.out.println("connected");
        session.close();
         
    }
}
