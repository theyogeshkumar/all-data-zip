package com.citiustech.one_to_one;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Machine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int machine_id;
	private String type;
	private String machine_name;
	
	@OneToOne(targetEntity = Employee.class)
	private Employee employee;
	
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public int getMachine_id() {
		return machine_id;
	}
	public void setMachine_id(int machine_id) {
		this.machine_id = machine_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMachine_name() {
		return machine_name;
	}
	public void setMachine_name(String machine_name) {
		this.machine_name = machine_name;
	}
	public Machine() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Machine(int machine_id, String type, String machine_name, Employee employee) {
		super();
		this.machine_id = machine_id;
		this.type = type;
		this.machine_name = machine_name;
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Machine [machine_id=" + machine_id + ", type=" + type + ", machine_name=" + machine_name + ", employee="
				+ employee + "]";
	}
	
	
	
	 

}
