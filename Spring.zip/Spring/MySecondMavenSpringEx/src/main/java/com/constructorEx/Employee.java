package com.constructorEx;

public class Employee {
	private String emp_name;
	private Department dept_name;
	public Employee(String emp_name, Department dept_name) {
		super();
		this.emp_name = emp_name;
		this.dept_name = dept_name;
	}
	@Override
	public String toString() {
		return "Employee [emp_name=" + emp_name + ", dept_name=" + dept_name + "]";
	}
	
	
}
