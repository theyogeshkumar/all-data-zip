package com.spring.autowiring;

public class Device {
	private int deviceId;
	private String deviceName;
	private String deviceType;
	public int getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(int deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
		System.out.println("in setter");
	}
	
	public Device() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Device(int deviceId, String deviceName, String deviceType) {
		super();
		this.deviceId = deviceId;
		this.deviceName = deviceName;
		this.deviceType = deviceType;
		System.out.println("in device cons");
	}
	@Override
	public String toString() {
		return "Device [deviceId=" + deviceId + ", deviceName=" + deviceName + ", deviceType=" + deviceType + "]";
	}
	
	

}
