package com.spring.service;

import java.util.List;

import com.spring.model.Speaker;

public interface SpeakerService {
	public List<Speaker> findAll();
}
