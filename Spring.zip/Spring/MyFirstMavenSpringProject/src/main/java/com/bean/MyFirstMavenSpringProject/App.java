package com.bean.MyFirstMavenSpringProject;


public class App 
{
    public static void main( String[] args )
    {
        
    }
}
