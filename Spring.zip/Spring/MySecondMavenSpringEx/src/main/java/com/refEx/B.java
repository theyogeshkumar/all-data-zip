package com.refEx;

public class B {
	private int number;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "B [number=" + number + "]";
	}
	
	 
}
