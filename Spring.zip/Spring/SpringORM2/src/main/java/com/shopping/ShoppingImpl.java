package com.shopping;

public class ShoppingImpl implements Shopping{

	public void buyProduct() {
		System.out.println("Buying Process Started");
		
		
		System.out.println("Purchase Done");
		
	}
	
}
