package com.citiustech.JavaDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JdbcTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		
//			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
//			Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
			System.out.println("Driver loded sucessfully");
//			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=AdventureWorks2019", "sa", "Password_123");
			Connection con = DriverManager.getConnection("jdbc:sqlserver://IMCCBCP280-MSL2\\SQLEXPRESS2019;databaseName=AdventureWorks2019;user=sa;password=Password_123");
			System.out.println("connection created sucessfully");
			
			Statement stmt= con.createStatement();
			stmt.execute("use AdventureWorks2019");
			ResultSet rs=stmt.executeQuery("select Top 100 AddressID,AddressLine1,AddressLine2,City from Person.Address Order by AddressID");
//			rs.next();
			
			
			while(rs.next()) {
				System.out.printf("%d\t%s\t%s\t%s",rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				System.out.println(); 
			}
			
			stmt.close();
			rs.close();
			con.close();
			System.out.println("connection closed");
		
			
		

	}

}
