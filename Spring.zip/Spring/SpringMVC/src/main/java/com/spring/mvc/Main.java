package com.spring.mvc;

import org.springframework.web.servlet.DispatcherServlet;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
