package com.autowiringusingxml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/autowiringusingxml/autowireconfig.xml");
		Emp emp=context.getBean("employee",Emp.class);
		System.out.println(emp);
	}
}
