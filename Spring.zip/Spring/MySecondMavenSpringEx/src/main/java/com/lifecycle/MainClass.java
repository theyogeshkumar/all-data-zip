package com.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("com/lifecycle/lifeconfig.xml");
//		Test obj=(Test)context.getBean("test");
//		
//		System.out.println(obj);
//		context.registerShutdownHook();
		
		Test3 obj=context.getBean("test3",Test3.class);
		System.out.println(obj);
		context.registerShutdownHook();
		
	}
}
