package com.citiustech.main;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

import com.citiustech.pojo.Student;
import com.citiustech.pojo.Subject;


public class App 
{
    public static void main( String[] args )
    {
        Configuration conf=new Configuration();
        conf.configure();
        SessionFactory sf= conf.buildSessionFactory();
        
        		
//    	SessionFactory sf= new Configuration().configure().buildSessionFactory();
        Session session = sf.openSession();
        Transaction t= session.beginTransaction();
        
        
        //insert data
//        Student s1= new Student("yogesh", 12,new Subject("English","hindi","maths","Science","computer"));
//        Student s2= new Student("akshay", 11,new Subject("English","hindi","maths","Science","computer"));
//        Student s3= new Student("shubham", 11,new Subject("English","hindi","maths","Science","computer"));
        
//        session.save(s1);
//        session.evict(s1);
//        s1.setName("sonu");
//        session.save(s2);
        //        session.save(s2);
//        session.save(s3);
//        session.saveOrUpdate(s1);
//        	session.persist(s1);
//        session.persist(s3);
//        	session.merge(s1);
//        	session.update(s1);
        
//        session.evict(s1);
//        s1.setName("ghnder");
//        session.save(s1);
//        session.cancelQuery();
       
        
        //get single data
//        int id=12;
//        Query qr= session.createQuery("from Student where roll_no=:a");
//        qr.setParameter("a", id);
//        Student s= (Student) qr.getSingleResult();
//        System.out.println(s);
        //get single data part 2  it throw null value and always hit query in sql 
//        Student s=session.get(Student.class, 200);
//        System.out.println(s);
        //get single data part 3 load onlu hit query when the user use the variable in code it throw onject not found exception
//        Student s= session.load(Student.class, 5);
//        System.out.println(s);
        
        
          //get alldata
        Query qr= session.createQuery("From Student");
//        List<Student> ls= qr.getResultList();
//        for (Student student : ls) {
//			System.out.println(student);
//		}
        //using iterator
//        List<Student> ls= qr.getResultList();
//        Iterator<Student> itr= ls.iterator();
//        while(itr.hasNext()) {
//        	System.out.println(itr.next());
//        }
        
        
        //delete value
//        int id=1;
//        Query qr= session.createQuery("delete From Student where id=:id");
//        qr.setParameter("id", id);
//        qr.executeUpdate();
        //delete method 2 for delete we have to first fetch the value then delete
//        	Student s=session.get(Student.class , 24);
//        	session.delete(s);
        
        //update value
//        String name="yogesh";
//        int id=2;
//        Query qr= session.createQuery("update Student set name=:a where id=:b");
//        qr.setParameter("a", name);
//        qr.setParameter("b", id);
//        qr.executeUpdate();
        
        //update method 2
//        	Student s=session.get(Student.class, 8);
//        	s.setName("vishwas");
//        	s.setStandard(111);
//        	s.setSubject(new Subject("hindi", "hindi", "hindi", "hindi", "hindi"));
        	//even if i dont use session.save it will automatically save my object 
        	//because it is connected with the session and does automatically it is in persist state. 
        	//        	session.save(s);
        
        	
        // update
//        Query qr= session.createQuery("update Student set sec=:g where roll_no=:b");
//        qr.setParameter("g", "abc");
//        qr.setParameter("b", 1);
//        qr.executeUpdate();
        
        //custom query by native Query
//        String name="vishwas";
//		NativeQuery<Student> q= session.createNativeQuery("update Student set name='"+name+"' where roll_no=1",Student.class);
//		q.executeUpdate();
		
		//native 1 select All
//		SQLQuery<Student> q1= session.createSQLQuery("select * from Student");
//		q1.addEntity(Student.class);
//        List<Student> ls= q1.list();
//        for (Student student : ls) {
//			System.out.println(student);
//		}
        
        //native 2 select
//        SQLQuery q=session.createSQLQuery("select name,standard,roll_no from student where sec='hindi'");
//        q.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
//        List data = q.list();
//
//        for(Object object : data) {
////           Map row = (Map)object;
//        	Object ls=(Object)object;
////           System.out.print("First Name: " + row.get("name")); 
////           System.out.println(", Standard: " + row.get("standard")); 
//           System.out.println(ls);
//        }
		
    
        
        t.commit();
        System.out.println("saved");
        session.close();
        sf.close();
    }
}
