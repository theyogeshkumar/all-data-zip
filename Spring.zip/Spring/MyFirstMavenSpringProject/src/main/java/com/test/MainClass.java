package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/test/student.xml");
		 Student obj= (Student) context.getBean("student1");
		 System.out.println(obj);
		 Student obj1= (Student) context.getBean("student2");
		 System.out.println(obj1);
		 Student obj2= (Student) context.getBean("student3");
		 System.out.println(obj2);
		
	}
}
