package com.threading;

public class SynchronousTest {
	
	public static void handleId(int jobId) {
		System.out.printf("Thread id <%d> has accepted and job id %d%n",Thread.currentThread().hashCode(),jobId);
		Worker.doWork(5);
		System.out.printf("Thread id <%d> has finished and job id %d%n",Thread.currentThread().hashCode(),jobId);
		Worker.doWork(1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println();
//		SynchronousTest a= new SynchronousTest();
		handleId(12);
		handleId(123);
		handleId(12);
		handleId(123);
	}

}
