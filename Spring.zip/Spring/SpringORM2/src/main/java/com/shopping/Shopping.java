package com.shopping;

public interface Shopping {

	public void buyProduct();
}
