package com.demo;

public class SamePackageStaticClass {

	 protected static int a=77;

}

