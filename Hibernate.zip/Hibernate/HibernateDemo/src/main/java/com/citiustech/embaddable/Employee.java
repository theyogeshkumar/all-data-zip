package com.citiustech.embaddable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee_Embaddable")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String first_nme;
	private String last_name;
	private double salary;
	
	private Location location;

	public String getFirst_nme() {
		return first_nme;
	}

	public void setFirst_nme(String first_nme) {
		this.first_nme = first_nme;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String first_nme, String last_name, double salary) {
		super();
		this.first_nme = first_nme;
		this.last_name = last_name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", first_nme=" + first_nme + ", last_name=" + last_name + ", salary=" + salary
				+ ", location=" + location + "]";
	}
	
	
	
	

}
