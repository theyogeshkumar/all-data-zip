package com.citiustech.embaddable;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmbaddableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SessionFactory sf= new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx= session.beginTransaction();
		
		
		
		Employee emp= new Employee("Yogesh", "Kumar", 510000);
		Employee e1=new Employee("Sonu", "Sisodia", 710000);
		Location l= new Location(110085, "New Delhi", "Delhi", "India");
		emp.setLocation(l);
		e1.setLocation(l);
		session.save(emp);
		session.save(e1);
		
		tx.commit();
		System.out.println("Inserted");
		
		session.close();
		sf.close();
		

	}

}
