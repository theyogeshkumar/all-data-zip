package com.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Test2 implements InitializingBean,DisposableBean{

	private int my_number;

	public int getMy_number() {
		return my_number;
	}

	public void setMy_number(int my_number) {
		System.out.println("setting values");
		this.my_number = my_number;
	}

	public Test2(int my_number) {
		super();
		this.my_number = my_number;
	}

	public Test2() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Test2 [my_number=" + my_number + "]";
	}

	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("This is My init Method");
	}

	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("This is My destroy Method");
	}
	
}
