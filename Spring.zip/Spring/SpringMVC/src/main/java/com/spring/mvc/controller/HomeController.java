package com.spring.mvc.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.mvc.model.User;
import com.spring.mvc.service.UserService;

@Controller
public class HomeController {

	
	@RequestMapping("/")
	public String home() {
		System.out.println("this is home url");
		return "indexx";
	}
	
	@RequestMapping("/ram")
	public String jaiShreeRam(Model model) {
		
		model.addAttribute("name1", "Jai Siya Ram");
		model.addAttribute("name2", "Raghupati Raghav Raja Ram");
		
		return "second";
	}
	@RequestMapping("/help")
	public ModelAndView help() {
		List<String> ls= new ArrayList<String>();
		ls.add("english");
		ls.add("hindi");
		ls.add("maths");
		ls.add("science");
		ls.add("social studies");
		ModelAndView mv= new ModelAndView();
		LocalDateTime time= LocalDateTime.now();
		mv.addObject("s",108);
		mv.addObject("time",time);
		mv.addObject("ls",ls);
		mv.setViewName("help");
		return mv;		
	}
	
	
//	@RequestMapping(path="/processform", method=RequestMethod.POST)
//	public String processform(@RequestParam("exampleInputUsername") String username,
//			@RequestParam("exampleInputEmail1") String email,@RequestParam("exampleInputPassword1") String password
//			,Model model) {
//		
//
//		System.out.println(email);
//		System.out.println(username);
//		System.out.println(password);
//		model.addAttribute("username", username);
//		model.addAttribute("email", email);
//		model.addAttribute("password", password);
//
//		return "processform";
//	}
	
	
	
}
