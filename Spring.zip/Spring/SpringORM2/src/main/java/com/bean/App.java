package com.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shopping.Shopping;


public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/Shopping/config.xml");
		Shopping buy = context.getBean("buyProduct", Shopping.class);
		buy.buyProduct();
	}
}