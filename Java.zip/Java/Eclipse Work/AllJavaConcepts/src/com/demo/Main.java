package com.demo;

import com.staticexample.FirstStaticClass;

public class Main {

	
	//non static function
	public void myName() {
		System.out.println("Akshay");
	}
	
//	this is my static function
	public static void printHello(String name) {
		System.out.printf("hello %s",name);
		System.out.println();
	}
	private static int a=4;
	protected static int b=34;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//static method can direct acces in the same class with using only method name. 
		printHello("Yogesh");
		printHello("akshay");
//		but if static method in another class we have to put its class name first and then use
//		.(dot) to access its memeber and function
		
		FirstStaticClass.printMyName("Yogesh");
		//direct acces if static member in same class 
		System.out.println(a);
		
		//if static is in another class then we have to need use
		//class name to access the static member and function
		System.out.println(SamePackageStaticClass.a);
		
//		System.out.println(FirstStaticClass.aa); 

		//public   	 	all
		//proctected 	same package and sub class in another package
		//default		same package only
		//private		same class only
		

	}

}
