package com.constructorEx;

public class Addition {

	private int a;
	private int b;
	public Addition(int a, int b) {
		super();
		System.out.println("This is Integer Type Constructor");
		this.a = a;
		this.b = b;
	}
	public Addition(String a, String b) {
		System.out.println("this is String Type Constructor");
		this.a=Integer.parseInt(a);
		this.b=Integer.parseInt(b);
	}
	@Override
	public String toString() {
		return "Addition [a=" + a + ", b=" + b + "]";
	}
	
	public void  performOperation() {
		System.out.println("Value of A="+this.a);
		System.out.println("Value of B="+this.b);
		System.out.println("Result ="+(this.a+this.b));
	}
}
