package com.threading;

public class ThreadCordinationtest {

	static Object obj = new Object();
	static int value;

	public static void producer() {
		System.out.println("Producer is ready.");
		Worker.doWork(5);
		value = 9;
		synchronized (obj) {
			obj.notifyAll();
		}

	}

	public static void consumer() {
		System.out.println("consumer is ready.");
		if (value == 0) {
			try {
				synchronized (obj) {
					obj.wait();
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("the outut is " + value * value);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				consumer();
			}
		});
		t.start();
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				consumer();
			}
		});
		t1.start();

		producer();
		

	}

}
