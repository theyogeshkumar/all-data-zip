package com.spring.annotation.autowiring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = "com.spring.annotation.autowiring")
@PropertySource("classpath:app.properties")
public class AnnotationConfig {
	
//	@Bean
//	public Address address() {
//		return new Address();
//		
//	}
//	@Bean
//	public Person person(){
//		Person p= new Person();
//		return p;
//	}
}
