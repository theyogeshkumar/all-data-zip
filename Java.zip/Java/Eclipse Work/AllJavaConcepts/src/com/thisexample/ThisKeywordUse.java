package com.thisexample;

public class ThisKeywordUse extends First {
	
	int a;
	int b;
	public ThisKeywordUse() {
		System.out.println("inside default constructor");
	}
	public ThisKeywordUse(int a,int b) {
		//this() is used to call the constructor of the current class
		//and this should be the first line in the constructor
		this();
		//first use to refer instance variable of class
		this.a=a;
		this.b=b;
		
		System.out.println("inside parametrized constructor");
	}
	public void fun(ThisKeywordUse thisKeywordUse) {
		System.out.println("inside fun");
		
	}
//	public ThisKeywordUse getObject()
//	   {
//		System.out.println("hello");
//	       return this;
//	   } 
	
//	public void fun() {
//		System.out.println("inside fun");
//		return ;
//		
//	}
	
	public void foo() {
		System.out.println("inside foo");
		//this: to call the method of the current class
		fun();
		//this: to use as a parameter in a method in line //public void fun(ThisKeywordUse thisKeywordUse)
//		fun(this);
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThisKeywordUse obj= new ThisKeywordUse(1,2);
		obj.foo();
		
	
	}

}
