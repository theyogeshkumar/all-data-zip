package com.constructorEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/constructorEx/refconfig.xml");
		Addition add= (Addition)context.getBean("addition");
		
		System.out.println(add);
		
		add.performOperation();
		
	}
}
