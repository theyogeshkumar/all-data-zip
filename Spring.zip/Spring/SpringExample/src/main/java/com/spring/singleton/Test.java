package com.spring.singleton;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext c=new ClassPathXmlApplicationContext("com/spring/singleton/config.xml");
		Stage s= c.getBean("stage",Stage.class);
		System.out.println(s);
		Stage s1= c.getBean("stage1",Stage.class);
		System.out.println(s1);
	}

}
