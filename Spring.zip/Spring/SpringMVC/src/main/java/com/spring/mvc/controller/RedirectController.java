package com.spring.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class RedirectController {
	
	@RequestMapping("mysearch") 
	public String mysearch() {
		return "mysearch";
	}
	
	@RequestMapping("search") 
	public RedirectView redirect(@RequestParam("query") String query) {
		RedirectView redirectView= new RedirectView();
		
		redirectView.setUrl("https://www.google.com/search?q="+query);
		return redirectView;
	}
	
	
	
	// how to redirect your view first method
//	@RequestMapping("/second")
//	public String second() {
//		return "redirect:mysearch";
//	}
	//second mothod of redirecting 
//	@RequestMapping("/second")
//	public RedirectView second() {
//		RedirectView redirectView = new RedirectView();
////		redirectView.setUrl("mysearch");
////		redirectView.setUrl("https://www.google.com/");
//		return redirectView;
//	}

}
