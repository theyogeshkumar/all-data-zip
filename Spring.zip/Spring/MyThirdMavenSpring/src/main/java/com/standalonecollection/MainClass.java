package com.standalonecollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		ApplicationContext context= new ClassPathXmlApplicationContext("com/standalonecollection/standaloneconfig.xml");
		Employee emp= context.getBean("employee",Employee.class);
		
		System.out.println(emp.getEmp_name());
		System.out.println(emp.getProject_name());
		System.out.println(emp.getProject_name().getClass());
		System.out.println();
		
		System.out.println(emp.getDepartment_details());
		System.out.println(emp.getDepartment_details().getClass());
		
		System.out.println();
		System.out.println(emp.getDbconnection());
		System.out.println(emp.getDbconnection().getClass());
		System.out.println(emp);
		
	}
}
