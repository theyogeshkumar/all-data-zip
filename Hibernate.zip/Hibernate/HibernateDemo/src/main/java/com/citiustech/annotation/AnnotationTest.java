package com.citiustech.annotation;


import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AnnotationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
			SessionFactory sf= new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			Session session = sf.openSession();
			Transaction t= session.beginTransaction();
			
			//insert 
			Employee emp=new Employee("shubham", "vishwakarma", 100000);
			Employee emp1=new Employee("akshay", "roy", 100000);
			session.save(emp);
			session.save(emp1);
			
			//update
//			Query qr1=session.createQuery("UPDATE Employee SET first_name =:first_name, last_name =:last_name, salary=:salary WHERE id=:id");
//			qr1.setParameter("first_name", "yogesh");
//			qr1.setParameter("last_name", "sisodia");
//			qr1.setParameter("salary", (double)1200120);
//			qr1.setParameter("id", 12);
//			qr1.executeUpdate();
			
			//getAll
			Query qr=session.createQuery("from Employee");
			List<Employee> ls=qr.getResultList();
			/*
			don't use executeupdate in the select query
			qr.executeUpdate();
			*/
			for (Employee employee : ls) {
				System.out.println(employee);
			}
			System.out.println();
			
			//get by id
//			Query qr=session.createQuery("from Employee where id=:a");
//			qr.setParameter("a", 8);
//			Employee empl = (Employee) qr.getSingleResult();
//			System.out.println(empl);
			
			
			//delete 
//			Query qr1=session.createQuery("delete from Employee where id=5");
//			qr1.executeUpdate();
			
			
			
			t.commit();
			session.close();
			sf.close();
		
		
		
	}

}
