package com.spring.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.model.Speaker;
@Repository("speakerRepository")
public class SpeakerRepositoryImpl implements SpeakerRepository {

	public List<Speaker> findAll() {
		
		
		List<Speaker> speakers= new ArrayList<Speaker>();
		Speaker speaker =new Speaker();
		speaker.setFirst_name("Yogesh");
		speaker.setLast_name("Sisodia");
		Speaker speaker1 =new Speaker();
		speaker1.setFirst_name("priyanka");
		speaker1.setLast_name("Sisodia");
		Speaker speaker2 =new Speaker();
		speaker2.setFirst_name("saurabh");
		speaker2.setLast_name("Sisodia");
		
		Speaker speaker3 =new Speaker();
		speaker3.setFirst_name("gaurav");
		speaker3.setLast_name("Sisodia");
		
		speakers.add(speaker);
		speakers.add(speaker1);
		speakers.add(speaker2);
		speakers.add(speaker3);
		
		return speakers;
	}

}
