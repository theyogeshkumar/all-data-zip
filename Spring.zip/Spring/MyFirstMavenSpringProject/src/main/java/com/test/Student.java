package com.test;

public class Student {

	private int stud_id;
	private String stud_name;
	private String stud_address;
	public int getStud_id() {
		return stud_id;
	}
	public void setStud_id(int stud_id) {
		System.out.println("This is My Setter Property");
		this.stud_id = stud_id;
	}
	public String getStud_name() {
		return stud_name;
	}
	public void setStud_name(String stud_name) {
		System.out.println("This is My Setter Property");
		this.stud_name = stud_name;
	}
	public String getStud_address() {
		return stud_address;
	}
	public void setStud_address(String stud_address) {
		System.out.println("This is My Setter Property");
		this.stud_address = stud_address;
	}
	public Student(int stud_id, String stud_name, String stud_address) {
		super();
		this.stud_id = stud_id;
		this.stud_name = stud_name;
		this.stud_address = stud_address;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [stud_id=" + stud_id + ", stud_name=" + stud_name + ", stud_address=" + stud_address + "]";
	}
	
	
	
}
