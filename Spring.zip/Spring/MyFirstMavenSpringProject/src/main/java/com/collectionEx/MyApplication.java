package com.collectionEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyApplication {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/collectionEx/employee.xml");
		Employee obj= (Employee) context.getBean("employee");
		
		System.out.println(obj);
		System.out.println();
		System.out.println("----------------- Employee Details ----------------");
		System.out.println(obj.getName());
		System.out.println(obj.getPhone());
		System.out.println(obj.getAddress());
		System.out.println(obj.getCourses());
	}
}
