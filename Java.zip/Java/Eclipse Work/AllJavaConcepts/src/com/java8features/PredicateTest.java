package com.java8features;

import java.util.ArrayList;
import java.util.function.Predicate;

import com.innerclass.AnonymousClass;

public class PredicateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<String> ps= (str) -> str.length()>4;
		
		Predicate<String> ps1 =new Predicate<String>() {

			@Override
			public boolean test(String t) {
				
				return t.length()>6;
			}

			
		};
		
		System.out.println(	ps1.test("Lalit Roshankhede"));
		
		System.out.println(ps.test("Yogesh Sisodia"));
		
		
	}

}
