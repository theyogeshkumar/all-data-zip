package com.spring.scope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopeTest {

	public static void main(String[] args) {
		
		ApplicationContext context= new ClassPathXmlApplicationContext("com/spring/scope/config.xml");
		System.out.println("__________initializing spring container______________");
		Car c1= context.getBean("c1",Car.class);
		System.out.println(c1);
//		Car c2= context.getBean("c2",Car.class);
//		System.out.println(c2);
		Car c3= context.getBean("c3",Car.class);
		System.out.println(c3);
		Car c4= context.getBean("c4",Car.class);
		System.out.println(c4);
		
		
		
		
	}
}
