package com.spring.autowiring;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int id;
	private String name;
	@Autowired
	private Device device;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
//		System.out.println("in setter");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
		System.out.println("in setter");
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("in emp cons default");
	}
	
	public Employee(int id, String name, Device device) {
		super();
		this.id = id;
		this.name = name;
		this.device = device;
		System.out.println("in employee cons");
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", device=" + device + "]";
	}
	

}
