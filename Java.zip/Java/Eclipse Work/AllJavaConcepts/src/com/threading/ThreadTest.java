package com.threading;

class ChildThread extends Thread{
	
	@Override
	public void run() {
		for(int i=1;i<=15;i++) {
			System.out.println(i);
		}
	}
	
	
}

class NewThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=15;i++) {
			System.out.println(i+" Runnable.");
		}
		
	}
	public void print() {
		System.out.println("Hello Bro");
	}
	
	
}
public class ThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Thread ct= new ChildThread();
//		NewThread a= new NewThread();
//		Thread t=new Thread(new NewThread());
//		Runnable r=new NewThread();
//		r.run();
//		ct.run();
//		ct.setName("Yogesh");
//		System.out.println(ct.getName());
//		ct.print();
//		ct.start();
//		t.start();
//		t.print();
//		
//		
//		a.run();
		
		Thread c= new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("run");
				
			}
		});
		
		c.start();
		
		
		

	}

}
