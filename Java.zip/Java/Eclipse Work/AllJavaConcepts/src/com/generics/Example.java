package com.generics;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println(sum(5,6)); 
		genericDisplay("Hello");
		genericDisplay(true);
		genericDisplay(1.1);
		genericDisplay(0);
		genericDisplay('A');
		genericDisplay(14567.928374f);
		

	}
	public static <T> void genericDisplay(T element)
    {
        System.out.println(element.getClass().getName()
                           + " = " + element);
    }
	public static Number sum(Number a,Number b) {
		Number c= a + b;
		return c;
	}
	

}
