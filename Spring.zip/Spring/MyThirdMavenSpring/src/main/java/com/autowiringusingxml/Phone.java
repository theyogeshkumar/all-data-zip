package com.autowiringusingxml;

public class Phone {
	private String pname;

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	@Override
	public String toString() {
		return "Phone [pname=" + pname + "]";
	}
	
}
