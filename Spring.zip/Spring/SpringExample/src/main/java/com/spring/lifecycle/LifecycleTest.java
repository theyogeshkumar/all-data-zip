package com.spring.lifecycle;

import javax.naming.Context;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LifecycleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		AbstractApplicationContext context= new ClassPathXmlApplicationContext("com/spring/lifecycle/config.xml");
		ConfigurableApplicationContext context= new ClassPathXmlApplicationContext("com/spring/lifecycle/config.xml");
		Student s= context.getBean("student",Student.class);
		System.out.println(s);
		
//		context.destroy();
		context.registerShutdownHook();
		
		//for calling the destroy method we have to enable pre shutdown hook from the AbstractApplicationContext interface
		//now we have to chane Application context to AbstractApplicationContext or configurable Application Context

	}	

}
